### antinuke
Use this tool to protect your discord servers against nukes.


### description
This tool protects your servers from 16 type of events and it has recovery feature like Flantic. the difference is, you need to pay for recovery feature in flantic and this bot is always free ❤️. This tool is tested on nukers like Lithium & PlayZ nuker, so no chance to bypass it 🔥

### Setup
#### Replit
- click [this](https://github.com/Sxlitude/antinuke/tree/main) for replit version.
#### Heroku
- create an account on heroku
- click [this link](https://dashboard.heroku.com/new?template=https://github.com/Sxlitude/antinuke/tree/heroku) & fill options
- once deployed, click `manage`
- from the top-right menu click `open app`
- copy the url of the redirected page (it must end with `...herokuapp.com`)
- use that url in [uptimerobot](https://uptimerobot.com/) (interval can be > 30 mins)
- done! you can click on `view logs` on the top-right, to see what's happening!

### Have issues?
if you find a bug in the antinuke or want to ask something about the bot, you can report it by opening an issue ;)
and hey u can contact me on discord too, i'm **Sxlitude#8885**
